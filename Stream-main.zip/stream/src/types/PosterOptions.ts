export default interface PosterOptions{
  id: string;
  title: string;
  image: string;
  type: "movie"|"tv"
}