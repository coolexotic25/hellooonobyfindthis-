export default {
  //Site display name
  SITE_TITLE: "Ripper+",

  //Put your discord link here or null to disable
  SITE_DISCORD: "https://ripper.lol/discord.html",
  
  //True or false to show or hide site credit in footer (You should leave enabled 😉)
  SITE_CREDITS: true,

  //Do not change or site will break!
  RIPPER_API: "https://api.ripper.fun"
}